from __future__ import annotations

import json
import zipfile
from pathlib import Path

import pytest

from hy3d_v2.hy3d_core.job_service import (
    HY3DError,
    create_job,
    create_job_package,
    create_new_version_from_accepted,
    export_active_accepted_stl,
    import_result_package,
    promote_to_accepted,
    save_manual_review,
    simulate_copy_exporter,
)
from hy3d_v2.hy3d_core.models import ReferenceView, ReviewPayload
from hy3d_v2.hy3d_core.utils.files import read_json


PNG_BYTES = (
    b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"
    b"\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\x0cIDAT\x08\xd7c\xf8\xff\xff?"
    b"\x00\x05\xfe\x02\xfeA\xe2&\x05\x00\x00\x00\x00IEND\xaeB`\x82"
)


def write_png(path: Path) -> Path:
    path.write_bytes(PNG_BYTES)
    return path


def write_dummy_glb(path: Path) -> Path:
    path.write_bytes(b"glTF")
    return path


def write_ascii_stl(_accepted_glb: Path, stl_path: Path) -> None:
    stl_path.write_text(
        "solid accepted\n"
        "facet normal 0 0 1\n"
        " outer loop\n"
        "  vertex 0 0 0\n"
        "  vertex 1 0 0\n"
        "  vertex 0 1 0\n"
        " endloop\n"
        "endfacet\n"
        "endsolid accepted\n",
        encoding="utf-8",
    )


@pytest.fixture()
def project_root(tmp_path: Path) -> Path:
    root = tmp_path / "hy3d_v2"
    (root / "jobs").mkdir(parents=True)
    return root


def test_create_job_and_package(project_root: Path) -> None:
    primary = write_png(project_root / "primary.png")
    extra = write_png(project_root / "side.png")
    manifest = create_job(
        project_root,
        primary,
        reference_views=[ReferenceView(path=extra, view_type="side")],
        prompt="make it clean",
        input_mode="multiple_views",
    )
    zip_path = create_job_package(project_root, manifest["job_id"])

    assert zip_path.exists()
    with zipfile.ZipFile(zip_path, "r") as archive:
        names = set(archive.namelist())
    assert "job_manifest.json" in names
    assert "input/primary_image.png" in names
    assert "multi_view/multi_view_manifest.json" in names
    assert "instructions/prompt.txt" in names

    job_manifest = read_json(project_root / "jobs" / manifest["job_id"] / "job_manifest.json")
    multi_view = read_json(project_root / "jobs" / manifest["job_id"] / "multi_view" / "multi_view_manifest.json")
    assert job_manifest["active_version"] == "v1"
    assert multi_view["reference_views"][0]["view_type"] == "side"


def test_import_result_package_creates_candidate_manifest(project_root: Path) -> None:
    primary = write_png(project_root / "primary.png")
    manifest = create_job(project_root, primary)
    result_zip = project_root / "result_package.zip"
    model_glb = write_dummy_glb(project_root / "model.glb")
    with zipfile.ZipFile(result_zip, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.write(model_glb, "model.glb")
        archive.writestr("result_manifest.json", json.dumps({"ok": True}))

    candidate = import_result_package(project_root, manifest["job_id"], result_zip)

    assert candidate["version_id"] == "v1"
    candidate_manifest = project_root / "jobs" / manifest["job_id"] / "versions" / "v1" / "engine_output" / "candidate_manifest.json"
    assert candidate_manifest.exists()


def test_save_review_and_promote_to_accepted(project_root: Path) -> None:
    primary = write_png(project_root / "primary.png")
    manifest = create_job(project_root, primary)
    candidate_glb = write_dummy_glb(project_root / "candidate.glb")
    review = ReviewPayload(4, 4, 4, "minor", True, "light", "usable candidate")
    review_path = save_manual_review(project_root, manifest["job_id"], "v1", review)
    accepted_path = promote_to_accepted(
        project_root,
        manifest["job_id"],
        "v1",
        exporter=simulate_copy_exporter(candidate_glb),
        accepted_object_name="Candidate",
        source_candidate_path=str(candidate_glb),
        human_edited=True,
    )

    assert review_path.exists()
    assert accepted_path.exists()
    accepted_manifest = read_json(accepted_path.parent / "accepted_manifest.json")
    assert accepted_manifest["accepted_source"] == "selected_blender_object"


def test_block_stl_without_accepted_model(project_root: Path) -> None:
    primary = write_png(project_root / "primary.png")
    manifest = create_job(project_root, primary)
    with pytest.raises(HY3DError, match="active accepted version"):
        export_active_accepted_stl(project_root, manifest["job_id"])


def test_export_stl_uses_accepted_model_only(project_root: Path) -> None:
    primary = write_png(project_root / "primary.png")
    manifest = create_job(project_root, primary)
    candidate_glb = write_dummy_glb(project_root / "candidate.glb")
    promote_to_accepted(
        project_root,
        manifest["job_id"],
        "v1",
        exporter=simulate_copy_exporter(candidate_glb),
        accepted_object_name="Accepted",
        source_candidate_path=str(candidate_glb),
        human_edited=False,
    )
    stl_path = export_active_accepted_stl(project_root, manifest["job_id"], exporter=write_ascii_stl)
    accepted_dir = project_root / "jobs" / manifest["job_id"] / "versions" / "v1" / "accepted"

    assert stl_path == accepted_dir / "accepted_model.stl"
    assert (accepted_dir / "stl_validation_report.json").exists()
    assert (accepted_dir / "printability_report.json").exists()


def test_create_second_version_from_active_accepted(project_root: Path) -> None:
    primary = write_png(project_root / "primary.png")
    manifest = create_job(project_root, primary)
    candidate_glb = write_dummy_glb(project_root / "candidate.glb")
    promote_to_accepted(
        project_root,
        manifest["job_id"],
        "v1",
        exporter=simulate_copy_exporter(candidate_glb),
        accepted_object_name="Accepted",
        source_candidate_path=str(candidate_glb),
        human_edited=False,
    )

    v2 = create_new_version_from_accepted(project_root, manifest["job_id"], "add more detail")

    assert v2["version_id"] == "v2"
    assert (project_root / "jobs" / manifest["job_id"] / "versions" / "v2" / "source" / "source_model.glb").exists()


def test_no_overwrite_same_version_accepted_glb(project_root: Path) -> None:
    primary = write_png(project_root / "primary.png")
    manifest = create_job(project_root, primary)
    candidate_glb = write_dummy_glb(project_root / "candidate.glb")
    promote_to_accepted(
        project_root,
        manifest["job_id"],
        "v1",
        exporter=simulate_copy_exporter(candidate_glb),
        accepted_object_name="Accepted",
        source_candidate_path=str(candidate_glb),
        human_edited=False,
    )
    with pytest.raises(HY3DError, match="already exists"):
        promote_to_accepted(
            project_root,
            manifest["job_id"],
            "v1",
            exporter=simulate_copy_exporter(candidate_glb),
            accepted_object_name="Accepted",
            source_candidate_path=str(candidate_glb),
            human_edited=False,
        )


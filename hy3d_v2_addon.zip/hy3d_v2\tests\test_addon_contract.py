from __future__ import annotations

from pathlib import Path


def test_addon_does_not_expose_legacy_routes() -> None:
    addon_source = Path(__file__).resolve().parents[1] / "blender_addon" / "__init__.py"
    content = addon_source.read_text(encoding="utf-8")
    forbidden = [
        "7A",
        "7B",
        "7C",
        "7X",
        "Relief",
        "prefer_3d_if_safe",
        "fallback_mode",
        "volumetric_mode",
    ]
    for item in forbidden:
        assert item not in content

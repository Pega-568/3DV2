"""HY3D v2 package root and Blender addon entrypoint."""

from .blender_addon import bl_info, register, unregister

__all__ = ["bl_info", "register", "unregister"]

from __future__ import annotations

import argparse
import json
from pathlib import Path

from hy3d_v2.hy3d_core.validation.service import validate_candidate_glb


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", type=Path, required=True)
    args = parser.parse_args()
    report = validate_candidate_glb(args.candidate)
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


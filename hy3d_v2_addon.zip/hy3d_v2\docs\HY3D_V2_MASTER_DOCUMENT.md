# HY3D v2 Master Document

## Resumen del proyecto
HY3D v2 es un sistema local para Blender orientado a un flujo GLB-first. La generación 3D pesada queda fuera de la PC local. El sistema local crea jobs, empaqueta entradas, importa resultados externos, valida candidatos, permite revisión/edición humana, promueve un GLB aceptado y exporta STL solo desde la versión aceptada activa.

## Objetivo final
Entregar un flujo estable y verificable:

1. Seleccionar imagen principal y vistas de referencia.
2. Crear `job_package.zip`.
3. Ejecutar generación externa fuera de Blender.
4. Importar `result_package.zip` con `model.glb`.
5. Revisar y editar el candidato en Blender.
6. Guardar el objeto editado como `accepted_model.glb`.
7. Exportar `accepted_model.stl` únicamente desde el aceptado activo.
8. Generar reportes JSON de validación.

## Decisiones de arquitectura
- El core nuevo vive en `hy3d_core` y no reutiliza el routing legacy.
- El add-on llama al core. No duplica la lógica de jobs, aceptación o STL.
- `model.glb` es candidato, no éxito final.
- `accepted_model.glb` es la fuente oficial para STL.
- `accepted_model.stl` es el único STL oficial del job.
- El sistema no depende de servidor permanente.
- La generación pesada queda preparada para ejecución externa por ZIP.

## Qué se descartó del sistema anterior
- Relief como núcleo.
- 2.5D como solución principal.
- Lógica 7A, 7B, 7C, 7X.
- `prefer_3d_if_safe`, `fallback_mode`, `volumetric_mode` y routing legacy.
- STL directo desde `model.glb`.
- Arquitectura multi-doc dispersa.
- Dependencia obligatoria de GPU local o servidor local persistente.

## Qué se reutiliza como idea
- Job aislado por carpeta.
- Artefactos JSON verificables.
- Validación ligera local antes de revisión humana.
- Blender como superficie de revisión, edición y promoción humana.

## Flujo completo GLB -> revisión humana -> STL
1. El usuario crea un job desde Blender o script.
2. El sistema guarda `job_manifest.json`, inputs y manifiestos multi-view.
3. El sistema crea `job_package.zip`.
4. Un worker externo produce `result_package.zip` con `model.glb`.
5. El sistema importa `model.glb`, crea `candidate_manifest.json` y `candidate_validation_report.json`.
6. El usuario importa el GLB candidato en Blender.
7. El usuario llena `manual_review.json`.
8. El usuario presiona `Use Selected Object as Accepted Model`.
9. El sistema exporta `accepted_model.glb`, guarda `accepted_manifest.json` y marca la versión como aceptada.
10. Solo entonces se permite exportar `accepted_model.stl`.
11. El sistema genera `stl_validation_report.json` y `printability_report.json`.

## Estructura del proyecto
```text
hy3d_v2/
  __init__.py
  blender_addon/
    __init__.py
  hy3d_core/
    __init__.py
    job_service.py
    models.py
    jobs/
    packaging/
    validation/
      service.py
    stl/
      service.py
    versions/
    utils/
      files.py
  scripts/
    create_job_package.py
    create_result_package.py
    import_result_package.py
    validate_candidate.py
    export_stl.py
  notebooks/
    HY3D_worker_colab.ipynb
  config/
    external_engines.example.json
  jobs/
  docs/
    HY3D_V2_MASTER_DOCUMENT.md
  tests/
    conftest.py
    test_phase1_flow.py
    test_addon_contract.py
```

## Contratos JSON
### `job_manifest.json`
```json
{
  "job_id": "job_xxx",
  "created_at": "2026-05-19T00:00:00+00:00",
  "status": "awaiting_external_generation",
  "active_version": "v1",
  "active_accepted_version": null,
  "versions": [
    {
      "version_id": "v1",
      "source_type": "image_to_3d",
      "status": "awaiting_external_generation"
    }
  ]
}
```

### `multi_view_manifest.json`
```json
{
  "job_id": "job_xxx",
  "input_mode": "multiple_views",
  "primary_image": "input/primary_image.png",
  "reference_views": [
    {
      "path": "input/original_uploads/image_01.png",
      "view_type": "side"
    }
  ]
}
```

### `multi_view_validation_report.json`
```json
{
  "image_count": 2,
  "primary_image": "input/primary_image.png",
  "reference_views": [],
  "accepted_for_generation": true,
  "warnings": []
}
```

### `source/source_type.json`
```json
{
  "version_id": "v1",
  "source_type": "image_to_3d",
  "input_mode": "single_image",
  "primary_image": "versions/v1/source/primary_image.png"
}
```

### `engine_output/candidate_manifest.json`
```json
{
  "job_id": "job_xxx",
  "version_id": "v1",
  "candidate_path": "E:/.../model.glb",
  "imported_at": "2026-05-19T00:00:00+00:00",
  "validation_status": "needs_human_review"
}
```

### `validation/candidate_validation_report.json`
```json
{
  "candidate_path": "E:/.../model.glb",
  "exists": true,
  "readable_by_trimesh": false,
  "readable_by_pyvista": false,
  "bbox": null,
  "component_count": null,
  "is_empty": false,
  "flatness_warning": false,
  "validation_status": "needs_human_review",
  "warnings": []
}
```

### `blender_review/manual_review.json`
```json
{
  "job_id": "job_xxx",
  "version_id": "v1",
  "saved_at": "2026-05-19T00:00:00+00:00",
  "warnings": [],
  "visual_score": 4,
  "geometry_score": 4,
  "object_similarity": 4,
  "holes_or_artifacts": "minor",
  "usable_as_base": true,
  "repair_needed": "light",
  "notes": "usable candidate"
}
```

### `accepted/accepted_manifest.json`
```json
{
  "job_id": "job_xxx",
  "version_id": "v1",
  "source_candidate_path": "E:/.../model.glb",
  "accepted_model_path": "E:/.../accepted_model.glb",
  "accepted_object_name": "Candidate",
  "human_edited": true,
  "accepted_at": "2026-05-19T00:00:00+00:00",
  "accepted_source": "selected_blender_object"
}
```

### `accepted/stl_validation_report.json`
Contiene el estado técnico del STL y un subreporte `printability_report`.

### `accepted/printability_report.json`
Estados posibles implementados:
- `print_ready_candidate`
- `needs_cleanup`
- `validation_unavailable`

## Estructura de carpetas de jobs
```text
jobs/<job_id>/
  job_manifest.json
  input/
    primary_image.png
    original_uploads/
  multi_view/
    multi_view_manifest.json
    multi_view_validation_report.json
    selected_primary_view.json
  instructions/
    prompt.txt
  versions/
    v1/
      source/
      engine_output/
      validation/
      blender_review/
        screenshots/
      edited/
      accepted/
```

## Flujo de versionado
- `v1` nace desde imagen.
- `v2` y siguientes se preparan desde el `accepted_model.glb` activo.
- Nunca se sobrescribe una versión previa.
- El core ya incluye `create_new_version_from_accepted(...)`.
- La modificación IA desde GLB queda preparada estructuralmente, no operativa aún desde Blender.

## Flujo multi-imagen
- Existe `input_mode` con `single_image` y `multiple_views`.
- Se exige una imagen primaria.
- Se acepta una vista adicional en la UI MVP actual.
- Se generan `multi_view_manifest.json`, `multi_view_validation_report.json` y `selected_primary_view.json`.
- Las vistas adicionales hoy sirven como referencia y packaging, no como reconstrucción multi-view real.

## Flujo de generación externa
- El sistema local crea `job_package.zip`.
- El worker externo debe devolver `result_package.zip` con `model.glb`.
- El notebook `notebooks/HY3D_worker_colab.ipynb` documenta el flujo manual MVP.
- No hay dependencia actual de Colab, Hugging Face o Modal para que el core local funcione.

## Validación geométrica
- Se ejecuta al importar `result_package.zip`.
- Usa `trimesh` si está disponible.
- Intenta marcar disponibilidad de PyVista sin convertirlo en requisito duro.
- Si una librería opcional falla o no existe, el sistema degrada y registra advertencias.
- La validación no autoacepta el modelo. Solo lo deja en `needs_human_review`.

## Revisión manual en Blender
Campos activos:
- `visual_score`
- `geometry_score`
- `object_similarity`
- `holes_or_artifacts`
- `usable_as_base`
- `repair_needed`
- `notes`

Regla implementada:
- Si `usable_as_base=true` con `visual_score < 3` o `geometry_score < 3`, se guarda advertencia en `manual_review.json`.

## Promoción a `accepted_model.glb`
- La promoción toma el objeto seleccionado en Blender.
- Exporta GLB usando `bpy.ops.export_scene.gltf(..., export_format="GLB")`.
- Guarda `accepted_manifest.json`.
- Actualiza `job_manifest.json` con `active_accepted_version`.
- No permite sobrescribir `accepted_model.glb` dentro de la misma versión sin nueva versión.

## Exportación a STL
- Está bloqueada si no existe `active_accepted_version`.
- Está bloqueada si no existe `accepted_model.glb`.
- Usa el objeto accepted cargado en Blender para exportar STL en la UI del add-on.
- En el core Python puede usar `trimesh` o un exporter inyectado.

## Validación STL
- Genera `stl_validation_report.json`.
- Genera `printability_report.json`.
- Si `trimesh` no puede validar, el estado queda en `validation_unavailable`.
- No se declara `print_ready_candidate` si no hay validación suficiente o si la malla no es watertight.

## Funciones del add-on
### Input
- `Create Job Package`
- `Open Job Folder`

### External Generation
- `Import Result Package`
- `Import Candidate GLB`

### Review / Edit
- `Save Review`
- `Use Selected Object as Accepted Model`

### STL
- `Export STL from Accepted Model`
- `Open Accepted Folder`

### Versioning
- Visualización de `job_id` y `version_id`
- Mensajes de funciones futuras para nueva versión y comparación

## Funciones externas pendientes
- Worker Colab real con motor configurado.
- Worker Kaggle real.
- Space de Hugging Face.
- Worker Modal.
- Integración de modificación IA desde `accepted_model.glb`.
- Comparación visual entre versiones.
- Carga de múltiples vistas en lista dinámica dentro del add-on.

## Cómo integrar Colab/Kaggle/Hugging Face/Modal en el futuro
### Colab/Kaggle
- Subir `job_package.zip`.
- Leer `job_manifest.json`.
- Ejecutar el motor externo.
- Escribir `model.glb`.
- Empaquetar `result_package.zip`.

### Hugging Face
- Crear un worker o Space que reciba `job_package.zip`.
- Mantener el mismo contrato de salida con `model.glb` y `result_manifest.json`.
- No depender de tokens hardcodeados.

### Modal
- Crear función serverless GPU que monte el package, ejecute el motor y devuelva `result_package.zip`.
- Mantener el mismo contrato ZIP para no cambiar el add-on.

## Pruebas realizadas
Pruebas automatizadas creadas:
- `test_create_job_and_package`
- `test_import_result_package_creates_candidate_manifest`
- `test_save_review_and_promote_to_accepted`
- `test_block_stl_without_accepted_model`
- `test_export_stl_uses_accepted_model_only`
- `test_create_second_version_from_active_accepted`
- `test_no_overwrite_same_version_accepted_glb`
- `test_addon_does_not_expose_legacy_routes`

Cobertura funcional de Fase 1:
- crear job
- crear `job_package.zip`
- importar `result_package.zip` simulado
- detectar `model.glb`
- guardar `candidate_manifest.json`
- guardar `manual_review.json`
- promover a `accepted_model.glb`
- bloquear STL sin accepted
- exportar STL desde accepted
- manejar `v1` y `v2`
- validar manifiesto multi-imagen
- evitar STL desde `model.glb`
- evitar sobrescritura de accepted
- verificar ausencia de UI legacy en el add-on

## Errores encontrados
- `pytest` no encontraba el paquete `hy3d_v2` durante la primera recolección. Se corrigió agregando `tests/conftest.py`.
- La validación opcional depende del stack local. Si `trimesh` o `pyvista` no están listos, el sistema degrada honestamente en lugar de declarar éxito falso.

## Pendientes
- Ejecutar smoke real con Blender instalado y ruta disponible.
- Empaquetar y verificar instalación del add-on ZIP dentro de Blender.
- Mejorar validación multi-imagen con heurísticas de UI/captura de pantalla.
- Soportar más de una vista adicional desde la UI.
- Agregar import/export explícito de `edited_model.glb`.
- Agregar botón futuro `Generate New Version from Accepted`.

## Estado actual verificable
### Funcionando
- Estructura base del proyecto.
- Documento maestro único.
- Creación de job local.
- Packaging de `job_package.zip`.
- Importación de `result_package.zip`.
- Generación de `candidate_manifest.json`.
- Guardado de `manual_review.json`.
- Promoción a `accepted_model.glb`.
- Bloqueo de STL si no hay accepted activo.
- Exportación de STL desde la versión accepted activa.
- Estructura preparada para `v2` desde `accepted_model.glb`.
- Add-on sin strings o rutas legacy en su superficie actual.

### Parcialmente implementado
- Validación geométrica: ligera y dependiente de librerías opcionales.
- Multi-view: estructural y de packaging, no reconstrucción real.
- Versionado avanzado en UI: preparado solo como placeholder.
- Notebook externo: preparado, no conectado a un motor real.

### Aún no probado
- Importación real en Blender de `model.glb`.
- Exportación real desde un objeto editado dentro de Blender.
- Exportación STL real desde Blender en esta máquina.
- Smoke completo con Blender headless.
- Worker real en Colab, Kaggle, Hugging Face o Modal.

## Bitácora de implementación
### 2026-05-19
- Archivo: `hy3d_v2/hy3d_core/job_service.py`
  Motivo: creación del flujo central de jobs, packaging, importación de candidatos, revisión, aceptación, versionado y STL.
- Archivo: `hy3d_v2/hy3d_core/validation/service.py`
  Motivo: validación ligera del candidato con degradación honesta si faltan dependencias opcionales.
- Archivo: `hy3d_v2/hy3d_core/stl/service.py`
  Motivo: exportación y validación STL separadas del candidato GLB.
- Archivo: `hy3d_v2/blender_addon/__init__.py`
  Motivo: panel MVP de Blender y operadores conectados al core nuevo.
- Archivo: `hy3d_v2/scripts/create_job_package.py`
  Motivo: CLI para crear job y package desde fuera de Blender.
- Archivo: `hy3d_v2/scripts/create_result_package.py`
  Motivo: empaquetado reusable de `result_package.zip`.
- Archivo: `hy3d_v2/scripts/import_result_package.py`
  Motivo: importación reusable del package de resultado.
- Archivo: `hy3d_v2/scripts/validate_candidate.py`
  Motivo: ejecución manual de validación de candidatos.
- Archivo: `hy3d_v2/scripts/export_stl.py`
  Motivo: exportación CLI del STL desde la versión aceptada activa.
- Archivo: `hy3d_v2/notebooks/HY3D_worker_colab.ipynb`
  Motivo: placeholder operativo para worker externo manual por ZIP.
- Archivo: `hy3d_v2/config/external_engines.example.json`
  Motivo: contrato base para futuros motores externos.
- Archivo: `hy3d_v2/tests/test_phase1_flow.py`
  Motivo: pruebas funcionales del flujo mínimo de Fase 1.
- Archivo: `hy3d_v2/tests/test_addon_contract.py`
  Motivo: prueba de contrato para evitar superficie legacy en el add-on.
- Archivo: `hy3d_v2/tests/conftest.py`
  Motivo: corregir importación del paquete durante `pytest`.
- Archivo: `hy3d_v2/__init__.py`
  Motivo: exponer `bl_info`, `register` y `unregister` para instalación del add-on como paquete.

from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT.parent))

from hy3d_v2.hy3d_core.job_service import (  # noqa: E402
    HY3DError,
    create_job,
    create_job_package,
    export_active_accepted_stl,
    import_result_package,
    promote_to_accepted,
    save_manual_review,
)
from hy3d_v2.hy3d_core.models import ReferenceView, ReviewPayload  # noqa: E402

bl_info = {
    "name": "HY3D v2",
    "author": "OpenAI Codex",
    "version": (0, 1, 0),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > HY3D v2",
    "description": "GLB-first local review workflow for external 3D generation",
    "category": "3D View",
}

try:  # pragma: no cover - Blender-only import
    import bpy
    from bpy.props import BoolProperty, EnumProperty, IntProperty, StringProperty
    from bpy.types import Operator, Panel, PropertyGroup

    BLENDER_AVAILABLE = True
except Exception:  # pragma: no cover - importable outside Blender for tests
    bpy = None
    BLENDER_AVAILABLE = False

    class Operator:  # type: ignore[override]
        pass

    class Panel:  # type: ignore[override]
        pass

    class PropertyGroup:  # type: ignore[override]
        pass

    def StringProperty(**_kwargs):  # type: ignore[misc]
        return None

    def BoolProperty(**_kwargs):  # type: ignore[misc]
        return None

    def EnumProperty(**_kwargs):  # type: ignore[misc]
        return None

    def IntProperty(**_kwargs):  # type: ignore[misc]
        return None


def addon_root() -> Path:
    return PROJECT_ROOT


def _selected_reference_views(props) -> list[ReferenceView]:
    views: list[ReferenceView] = []
    if getattr(props, "additional_view_path", ""):
        views.append(ReferenceView(path=Path(props.additional_view_path), view_type=props.additional_view_type))
    return views


def _active_job_dir(props) -> Path:
    return addon_root() / "jobs" / props.job_id


if BLENDER_AVAILABLE:  # pragma: no branch
    class HY3DProperties(PropertyGroup):
        input_mode: EnumProperty(
            name="Input Mode",
            items=[("single_image", "Single Image", ""), ("multiple_views", "Multiple Views", "")],
            default="single_image",
        )
        primary_image_path: StringProperty(name="Primary Image", subtype="FILE_PATH")
        additional_view_path: StringProperty(name="Additional View", subtype="FILE_PATH")
        additional_view_type: EnumProperty(
            name="View Type",
            items=[
                ("front", "front", ""),
                ("side", "side", ""),
                ("back", "back", ""),
                ("top", "top", ""),
                ("detail", "detail", ""),
                ("unknown", "unknown", ""),
            ],
            default="unknown",
        )
        prompt: StringProperty(name="Prompt", default="")
        target_size: StringProperty(name="Target Size", default="")
        job_id: StringProperty(name="Job ID", default="")
        version_id: StringProperty(name="Version ID", default="v1")
        result_package_path: StringProperty(name="Result Package", subtype="FILE_PATH")
        candidate_path: StringProperty(name="Candidate Path", default="")
        accepted_model_path: StringProperty(name="Accepted Model Path", default="")
        visual_score: IntProperty(name="Visual Score", default=3, min=0, max=5)
        geometry_score: IntProperty(name="Geometry Score", default=3, min=0, max=5)
        object_similarity: IntProperty(name="Object Similarity", default=3, min=0, max=5)
        holes_or_artifacts: EnumProperty(
            name="Holes / Artifacts",
            items=[("none", "none", ""), ("minor", "minor", ""), ("moderate", "moderate", ""), ("severe", "severe", "")],
            default="none",
        )
        usable_as_base: BoolProperty(name="Usable as Base", default=False)
        repair_needed: EnumProperty(
            name="Repair Needed",
            items=[("none", "none", ""), ("light", "light", ""), ("heavy", "heavy", ""), ("impossible", "impossible", "")],
            default="none",
        )
        review_notes: StringProperty(name="Notes", default="")


    class HY3D_OT_CreateJobPackage(Operator):
        bl_idname = "hy3d_v2.create_job_package"
        bl_label = "Create Job Package"

        def execute(self, context):
            props = context.scene.hy3d_v2
            try:
                manifest = create_job(
                    addon_root(),
                    Path(props.primary_image_path),
                    reference_views=_selected_reference_views(props),
                    prompt=props.prompt or None,
                    input_mode=props.input_mode,
                )
                zip_path = create_job_package(addon_root(), manifest["job_id"])
                props.job_id = manifest["job_id"]
                props.version_id = "v1"
                self.report({"INFO"}, f"Created {zip_path.name}")
                return {"FINISHED"}
            except Exception as exc:
                self.report({"ERROR"}, str(exc))
                return {"CANCELLED"}


    class HY3D_OT_OpenJobFolder(Operator):
        bl_idname = "hy3d_v2.open_job_folder"
        bl_label = "Open Job Folder"

        def execute(self, context):
            props = context.scene.hy3d_v2
            if not props.job_id:
                self.report({"ERROR"}, "No active job")
                return {"CANCELLED"}
            bpy.ops.wm.path_open(filepath=str(_active_job_dir(props)))
            return {"FINISHED"}


    class HY3D_OT_ImportResultPackage(Operator):
        bl_idname = "hy3d_v2.import_result_package"
        bl_label = "Import Result Package"

        def execute(self, context):
            props = context.scene.hy3d_v2
            try:
                manifest = import_result_package(
                    addon_root(),
                    props.job_id,
                    Path(props.result_package_path),
                    version_id=props.version_id or "v1",
                )
                props.candidate_path = manifest["candidate_path"]
                self.report({"INFO"}, "Candidate imported into job")
                return {"FINISHED"}
            except Exception as exc:
                self.report({"ERROR"}, str(exc))
                return {"CANCELLED"}


    class HY3D_OT_ImportCandidateGLB(Operator):
        bl_idname = "hy3d_v2.import_candidate_glb"
        bl_label = "Import Candidate GLB"

        def execute(self, context):
            props = context.scene.hy3d_v2
            candidate = Path(props.candidate_path)
            if not candidate.exists():
                self.report({"ERROR"}, "Candidate GLB not found")
                return {"CANCELLED"}
            bpy.ops.import_scene.gltf(filepath=str(candidate))
            for obj in context.selected_objects:
                obj["hy3d_job_id"] = props.job_id
                obj["hy3d_version_id"] = props.version_id
                obj["hy3d_role"] = "candidate"
                obj["hy3d_source_path"] = str(candidate)
            self.report({"INFO"}, "Candidate GLB imported")
            return {"FINISHED"}


    class HY3D_OT_SaveReview(Operator):
        bl_idname = "hy3d_v2.save_review"
        bl_label = "Save Review"

        def execute(self, context):
            props = context.scene.hy3d_v2
            review = ReviewPayload(
                visual_score=props.visual_score,
                geometry_score=props.geometry_score,
                object_similarity=props.object_similarity,
                holes_or_artifacts=props.holes_or_artifacts,
                usable_as_base=props.usable_as_base,
                repair_needed=props.repair_needed,
                notes=props.review_notes,
            )
            try:
                save_manual_review(addon_root(), props.job_id, props.version_id, review)
                self.report({"INFO"}, "Review saved")
                return {"FINISHED"}
            except Exception as exc:
                self.report({"ERROR"}, str(exc))
                return {"CANCELLED"}


    class HY3D_OT_UseSelectedAsAccepted(Operator):
        bl_idname = "hy3d_v2.use_selected_as_accepted"
        bl_label = "Use Selected Object as Accepted Model"

        def execute(self, context):
            props = context.scene.hy3d_v2
            obj = context.active_object
            if obj is None:
                self.report({"ERROR"}, "Select one object first")
                return {"CANCELLED"}

            def exporter(destination: Path) -> None:
                destination.parent.mkdir(parents=True, exist_ok=True)
                previous_selection = list(context.selected_objects)
                previous_active = context.view_layer.objects.active
                bpy.ops.object.select_all(action="DESELECT")
                obj.select_set(True)
                context.view_layer.objects.active = obj
                bpy.ops.export_scene.gltf(filepath=str(destination), use_selection=True, export_format="GLB")
                obj["hy3d_role"] = "accepted"
                obj["hy3d_job_id"] = props.job_id
                obj["hy3d_version_id"] = props.version_id
                obj["hy3d_source_path"] = props.candidate_path
                bpy.ops.object.select_all(action="DESELECT")
                for previous in previous_selection:
                    previous.select_set(True)
                context.view_layer.objects.active = previous_active

            try:
                accepted_path = promote_to_accepted(
                    addon_root(),
                    props.job_id,
                    props.version_id,
                    exporter=exporter,
                    accepted_object_name=obj.name,
                    source_candidate_path=props.candidate_path,
                    human_edited=True,
                )
                props.accepted_model_path = str(accepted_path)
                self.report({"INFO"}, "Accepted GLB exported")
                return {"FINISHED"}
            except Exception as exc:
                self.report({"ERROR"}, str(exc))
                return {"CANCELLED"}


    class HY3D_OT_ExportAcceptedSTL(Operator):
        bl_idname = "hy3d_v2.export_accepted_stl"
        bl_label = "Export STL from Accepted Model"

        def execute(self, context):
            props = context.scene.hy3d_v2

            def exporter(_accepted_glb: Path, stl_path: Path) -> None:
                accepted_object = None
                for obj in bpy.data.objects:
                    if obj.get("hy3d_job_id") == props.job_id and obj.get("hy3d_version_id") == props.version_id and obj.get("hy3d_role") == "accepted":
                        accepted_object = obj
                        break
                if accepted_object is None:
                    raise HY3DError("Load or accept an object in Blender before STL export")
                previous_selection = list(context.selected_objects)
                previous_active = context.view_layer.objects.active
                bpy.ops.object.select_all(action="DESELECT")
                accepted_object.select_set(True)
                context.view_layer.objects.active = accepted_object
                bpy.ops.export_mesh.stl(filepath=str(stl_path), use_selection=True)
                bpy.ops.object.select_all(action="DESELECT")
                for previous in previous_selection:
                    previous.select_set(True)
                context.view_layer.objects.active = previous_active

            try:
                stl_path = export_active_accepted_stl(addon_root(), props.job_id, exporter=exporter)
                self.report({"INFO"}, f"Exported {stl_path.name}")
                return {"FINISHED"}
            except Exception as exc:
                self.report({"ERROR"}, str(exc))
                return {"CANCELLED"}


    class HY3D_OT_OpenAcceptedFolder(Operator):
        bl_idname = "hy3d_v2.open_accepted_folder"
        bl_label = "Open Accepted Folder"

        def execute(self, context):
            props = context.scene.hy3d_v2
            if not props.accepted_model_path:
                self.report({"ERROR"}, "No accepted model path")
                return {"CANCELLED"}
            bpy.ops.wm.path_open(filepath=str(Path(props.accepted_model_path).parent))
            return {"FINISHED"}


    class HY3D_PT_MainPanel(Panel):
        bl_idname = "HY3D_PT_main_panel"
        bl_label = "HY3D v2"
        bl_space_type = "VIEW_3D"
        bl_region_type = "UI"
        bl_category = "HY3D v2"

        def draw(self, context):
            props = context.scene.hy3d_v2
            layout = self.layout

            box = layout.box()
            box.label(text="Input")
            box.prop(props, "input_mode")
            box.prop(props, "primary_image_path")
            box.prop(props, "additional_view_path")
            box.prop(props, "additional_view_type")
            box.prop(props, "prompt")
            box.prop(props, "target_size")
            box.operator("hy3d_v2.create_job_package")
            box.operator("hy3d_v2.open_job_folder")

            box = layout.box()
            box.label(text="External Generation")
            box.prop(props, "job_id")
            box.prop(props, "version_id")
            box.prop(props, "result_package_path")
            box.operator("hy3d_v2.import_result_package")
            box.prop(props, "candidate_path")
            box.operator("hy3d_v2.import_candidate_glb")

            box = layout.box()
            box.label(text="Review / Edit")
            box.prop(props, "visual_score")
            box.prop(props, "geometry_score")
            box.prop(props, "object_similarity")
            box.prop(props, "holes_or_artifacts")
            box.prop(props, "usable_as_base")
            box.prop(props, "repair_needed")
            box.prop(props, "review_notes")
            box.operator("hy3d_v2.save_review")
            box.operator("hy3d_v2.use_selected_as_accepted")

            box = layout.box()
            box.label(text="STL")
            box.prop(props, "accepted_model_path")
            box.operator("hy3d_v2.export_accepted_stl")
            box.operator("hy3d_v2.open_accepted_folder")

            box = layout.box()
            box.label(text="Versioning")
            box.label(text=f"Active Version: {props.version_id or 'v1'}")
            box.label(text="Generate New Version from Accepted: future")
            box.label(text="Compare Versions: future")


    classes = (
        HY3DProperties,
        HY3D_OT_CreateJobPackage,
        HY3D_OT_OpenJobFolder,
        HY3D_OT_ImportResultPackage,
        HY3D_OT_ImportCandidateGLB,
        HY3D_OT_SaveReview,
        HY3D_OT_UseSelectedAsAccepted,
        HY3D_OT_ExportAcceptedSTL,
        HY3D_OT_OpenAcceptedFolder,
        HY3D_PT_MainPanel,
    )


    def register():
        for cls in classes:
            bpy.utils.register_class(cls)
        bpy.types.Scene.hy3d_v2 = bpy.props.PointerProperty(type=HY3DProperties)


    def unregister():
        del bpy.types.Scene.hy3d_v2
        for cls in reversed(classes):
            bpy.utils.unregister_class(cls)

else:
    classes = ()

    def register():
        return None


    def unregister():
        return None

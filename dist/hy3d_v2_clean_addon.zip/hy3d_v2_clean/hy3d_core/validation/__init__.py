"""Validation helpers."""


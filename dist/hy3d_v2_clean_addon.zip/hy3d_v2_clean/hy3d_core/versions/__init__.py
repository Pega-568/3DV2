"""Version management helpers."""

